package com.resmenu.interfaces;

import com.resmenu.Database.Entity.MyCart;

import java.util.ArrayList;

public interface DataTransfer {
    void setValues(double total);
}